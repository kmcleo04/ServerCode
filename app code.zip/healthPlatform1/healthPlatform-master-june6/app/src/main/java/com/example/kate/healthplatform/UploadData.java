package com.example.kate.healthplatform;

import android.app.Dialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class UploadData extends AsyncTask<String, String, Integer> {

    private Dialog progressDialog;
    private ProgressBar progressBar;
    private Context context;
    private MainActivity activity;

    UploadData(Context context, MainActivity activity){
        progressDialog = new Dialog(context, R.style.Theme_AppCompat_Dialog_Alert);
        progressDialog.setTitle("Uploading data");
        progressDialog.setContentView(R.layout.dialog_upload);
        progressBar = progressDialog.getWindow().findViewById(R.id.uploadDataProgress);
        this.context = context;
        this.activity = activity;
    }

    @Override
    protected void onPreExecute() {
        progressDialog.show();
        super.onPreExecute();
    }

    @Override
    protected Integer doInBackground(String... urls) {
        int resultCode = 0;
        try {
            URL url = new URL(urls[0]);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            conn.setRequestProperty("Accept","application/json");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setConnectTimeout(3000);

            JSONObject jsonParam = new JSONObject();
            jsonParam.put("Beacon Address", DatabasePool.getBeaconAddr(context));
            jsonParam.put("Session Number", MainActivity.getSessionNumber());
            jsonParam.put("Datetime", MainActivity.getDay_Text());
            jsonParam.put("TimeStart", MainActivity.getTimeStart());
            jsonParam.put("TimeEnd", MainActivity.getTimeEnd());
            jsonParam.put("AvgAudio", MainActivity.getAudioAvg());
            jsonParam.put("MaxTemp", MainActivity.getTempHigh());
            jsonParam.put("MinTemp", MainActivity.getTempLow());
            jsonParam.put("AvgTemp", MainActivity.getTempAvg());
            jsonParam.put("AvgHumidity", MainActivity.getHumAvg());
            jsonParam.put("SensorLog", DatabasePool.getDb().JSONSensorArray());
            jsonParam.put("SurveyResults", MainActivity.JSONSurveyArray());

            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
            byte[] stringBytes = jsonParam.toString().getBytes(StandardCharsets.UTF_8);
            ByteArrayInputStream is = new ByteArrayInputStream(stringBytes);

            int maxBufferSize = 4096;
            byte[] buffer = new byte[maxBufferSize];
            long length = stringBytes.length;
            int bytesRead;
            long total = 0;

            while ((bytesRead = is.read(buffer, 0, maxBufferSize)) > 0) {
                total += bytesRead;
                publishProgress("" + (int) ((total * 100) / length));
                os.write(buffer, 0, bytesRead);
            }

            os.flush();
            os.close();

            resultCode = conn.getResponseCode();
            conn.disconnect();
        }catch (java.net.SocketTimeoutException e) {
            return 404;
        } catch (java.io.IOException e) {
            return 404;
        }catch (Exception e) {
            e.printStackTrace();
        }

        return resultCode;
    }

    protected void onProgressUpdate(String... progress) {
        progressBar.setProgress(Integer.parseInt(progress[0]));
    }

    @Override
    protected void onPostExecute(Integer resultCode) {
        progressDialog.dismiss();
        if(resultCode == 201) {
            activity.resetSessionInformation();
            DatabasePool.deleteDb(context);
            Toast.makeText(context, "Successfully uploaded", Toast.LENGTH_SHORT).show();
        } else if(resultCode == 409) {
            Toast.makeText(context, "The experiment name already exists, please pick a new name", Toast.LENGTH_LONG).show();
            MainActivity.changeValues(MainActivity.NAME, context, activity);
        } else if((resultCode == 404) || (resultCode == 0)){
            Toast.makeText(context, "Cannot Connect to results server", Toast.LENGTH_SHORT).show();
            MainActivity.changeValues(MainActivity.SERVER, context, activity);
        } else if(resultCode == 412){
            Toast.makeText(context, "Submission has invalid values and cannot be accepted", Toast.LENGTH_SHORT).show();
        } else{
            Toast.makeText(context, "RESULT CODE: " + Integer.toString(resultCode), Toast.LENGTH_SHORT).show();
        }

        super.onPostExecute(resultCode);
    }

    @Override
    protected void onCancelled() {
        progressDialog.dismiss();
        super.onCancelled();
    }
}
