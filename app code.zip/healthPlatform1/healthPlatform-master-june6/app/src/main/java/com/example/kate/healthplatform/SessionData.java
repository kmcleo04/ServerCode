package com.example.kate.healthplatform;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class SessionData extends AppCompatActivity {

    private static String tokenS = "@";
    private static String tokenN = "$";
    private ArrayList<String> list = new ArrayList<String>();
    private static String rawString = "";
    private TextView data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_session_data);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        data = (TextView) findViewById(R.id.editText);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    public void loadFile(){

        // The file will be loaded and displayed
        Bundle b = getIntent().getExtras();
        String mainFile = b.getString("key");


            try {
                Log.i("input:", "attempting open file");
                InputStream inputStream = openFileInput(mainFile);


                if (inputStream != null) {
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String receiveString = "";
                    StringBuilder stringBuilder = new StringBuilder();

                    try {
                        while ((receiveString = bufferedReader.readLine()) != null) {
                            stringBuilder.append(receiveString);
                        }

                        inputStream.close();
                        rawString = stringBuilder.toString();

                    } catch (IOException e) {
                        Log.i("input:", "crashing inner");
                        e.printStackTrace();

                    }
                }
            }
            catch (FileNotFoundException e) {
                Log.i("input:", "crashing outer");
                e.printStackTrace();
            }

    }

}
