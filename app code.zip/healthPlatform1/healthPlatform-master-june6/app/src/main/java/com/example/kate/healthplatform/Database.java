package com.example.kate.healthplatform;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class Database extends SQLiteOpenHelper{

    private static final String DATABASE_NAME = "experiment_database";
    private static final String SENSOR_TABLE = "sensors";
    private static final String DATETIME = "datetime";
    private static final String AUDIO_SENSOR = "audio";
    private static final String TEMPERATURE_SENSOR = "temperature";
    private static final String LIGHT_SENSOR = "light";
    private static final String HUMIDITY_SENSOR = "humidity";
    private static final String PRESSURE_SENSOR = "pressure";
    //private static final String MOVE_SENSOR = "move";


    public Database(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + SENSOR_TABLE + "(" + DATETIME + " TEXT, " + AUDIO_SENSOR + " TEXT, " + PRESSURE_SENSOR + " DOUBLE, " + TEMPERATURE_SENSOR + " DOUBLE, " + HUMIDITY_SENSOR + " DOUBLE, " + LIGHT_SENSOR + " DOUBLE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + SENSOR_TABLE);
        onCreate(db);
    }

    public boolean insertSensorData(double temperature, double humidity){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATETIME, getDatetime());
        contentValues.put(AUDIO_SENSOR, -111111);
        contentValues.put(TEMPERATURE_SENSOR, temperature);
        contentValues.put(HUMIDITY_SENSOR, humidity);
        //contentValues.put(MOVE_SENSOR, -111111);
        contentValues.put(PRESSURE_SENSOR, -111111);
        contentValues.put(LIGHT_SENSOR, -111111);
        long result = db.insert(SENSOR_TABLE, null, contentValues);
        if(result == -1){
            return false;
        }
        return true;
    }

    public boolean insertAudioSensorData(double audio){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATETIME, getDatetime());
        contentValues.put(AUDIO_SENSOR, audio);
        contentValues.put(PRESSURE_SENSOR, -111111);
        //contentValues.put(MOVE_SENSOR, -111111);
        contentValues.put(LIGHT_SENSOR, -111111);
        contentValues.put(TEMPERATURE_SENSOR, -111111);
        contentValues.put(HUMIDITY_SENSOR, -111111);
        long result = db.insert(SENSOR_TABLE, null, contentValues);
        if(result == -1){
            return false;
        }
        return true;
    }

    public boolean insertPressureSensorData(double pressure){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATETIME, getDatetime());
        contentValues.put(AUDIO_SENSOR, -111111);
        contentValues.put(PRESSURE_SENSOR, pressure);
        //contentValues.put(MOVE_SENSOR, -111111);
        contentValues.put(LIGHT_SENSOR, -111111);
        contentValues.put(TEMPERATURE_SENSOR, -111111);
        contentValues.put(HUMIDITY_SENSOR, -111111);
        long result = db.insert(SENSOR_TABLE, null, contentValues);
        if(result == -1){
            return false;
        }
        return true;
    }

    public boolean insertMoveSensorData(double move){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATETIME, getDatetime());
        contentValues.put(AUDIO_SENSOR, -111111);
        //contentValues.put(MOVE_SENSOR, move);
        contentValues.put(LIGHT_SENSOR, -111111);
        contentValues.put(PRESSURE_SENSOR, -111111);
        contentValues.put(TEMPERATURE_SENSOR, -111111);
        contentValues.put(HUMIDITY_SENSOR, -111111);
        long result = db.insert(SENSOR_TABLE, null, contentValues);
        if(result == -1){
            return false;
        }
        return true;
    }

    public boolean insertLightSensorData(double light){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATETIME, getDatetime());
        contentValues.put(AUDIO_SENSOR, -111111);
        contentValues.put(LIGHT_SENSOR, light);
        //contentValues.put(MOVE_SENSOR, -111111);
        contentValues.put(PRESSURE_SENSOR, -111111);
        contentValues.put(TEMPERATURE_SENSOR, -111111);
        contentValues.put(HUMIDITY_SENSOR, -111111);
        long result = db.insert(SENSOR_TABLE, null, contentValues);
        if(result == -1){
            return false;
        }
        return true;
    }

    private String getDatetime(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.CANADA);
        dateFormat.setTimeZone(TimeZone.getDefault());
        return dateFormat.format(new Date());
    }

    public JSONArray JSONSensorArray(){
        JSONArray ja = new JSONArray();
        try {
            SQLiteDatabase db = DatabasePool.getDb().getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + SENSOR_TABLE, null);
            while (cursor.moveToNext()) {
                JSONObject jo = new JSONObject();
                jo.put("Datetime", cursor.getString(0));

                JSONArray da = new JSONArray();
                da.put(cursor.getDouble(1));
                da.put(cursor.getDouble(2));
                da.put(cursor.getDouble(3));
                da.put(cursor.getDouble(4));
                da.put(cursor.getDouble(5));

                jo.put("Data", da);

                ja.put(jo);
            }
            cursor.close();
        }catch(JSONException e){
            e.printStackTrace();
        }
        return ja;
    }
}
