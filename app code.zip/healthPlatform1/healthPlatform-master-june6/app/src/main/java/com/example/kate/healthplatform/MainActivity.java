package com.example.kate.healthplatform;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


public final class MainActivity extends AppCompatActivity /*implements BluetoothAdapter.LeScanCallback*/ {

    LocationManager locationManager;

    public Context context;
    public final MainActivity activity = this;

    private static final int MY_PERMISSION_ACCESS_COARSE_LOCATION = 11;

    //Define server to send results to
    private static String results_server = "http://10.16.9.159:5000/results/";

    //Define survey request
    private static final int SURVEY_REQUEST = 1;

    //Types of values to change
    static final int NAME = 0;
    static final int SERVER = 1;

    // Custom variables for bluetooth connection
    private static BluetoothAdapter mBluetoothAdapter;
    private static SparseArray<BluetoothDevice> mDevices;
    private ProgressDialog mProgress;
    private TextView mAudio;
    private TextView mTemperature;
    private TextView mPressure;
    private TextView mLight;
    private TextView mMove;
    private TextView data;

    // This is the temperature variables needed
    private static double tempAvg = 0;
    private static int cycle = 0;
    private static double audioAvg = 0;
    private static double tempHigh = -100;
    private static double tempLow = 100;
    private static double tempTotal = 0;
    private static double humAvg = 0;
    private static double humTotal = 0;
    private static double moveAvg = 0;
    private static double moveTotal = 0;
    private static double lightAvg = 0;
    private static double lightTotal = 0;
    private static double baroAvg = 0;
    private static double baroTotal = 0;
    private static double humCurrent = 0;
    public String previousDateSubmitted="0";  //not in Evan's code

    // Variables for session running time
    private static long timeStart = 0;
    private static long timeEnd = 0;
    private static boolean sessionAllowed = false;
    private static boolean bleConnected = false;
    private static boolean beaconRegistered = false;
    private static boolean click = false;

    // Variables for string storage
    private static String day_Text;
    private static int sessionNumber = 0;

    // File Variables for storage
    public static String testFile = "testfile5";
    private static String rawString = "";

    //Connecting dialog
    private static Dialog connectingDialog;

    //Bluetooth thread
    BluetoothThread bluetoothThread;
    Handler bluetoothThreadHandler;

    private Button startStopButton;
    private Button disconnectConnectButton;
    private Button registerDeregisterButton;

    private static ArrayList<Integer> questions;

    static final int MSG_HANDLER = 1;
    static final int MSG_TOAST = 2;
    static final int MSG_START_CONNECTION_DIALOG = 101;
    static final int MSG_BEACON_REGISTERED = 102;
    static final int MSG_RETURN_SESSION_DATA = 103;
    static final int MSG_CONNECTED = 200;
    static final int MSG_DISCONNECTED = 201;
    static final int MSG_CLEAR_DISPLAY_VALUES = 401;
    static final int MSG_SET_AUDIO_TEXT = 501;
    static final int MSG_SET_TEMP_HUM_TEXT = 502;
    static final int MSG_SET_LIGHT_TEXT = 503;
    static final int MSG_SET_PRESSURE_TEXT = 504;
    static final int MSG_SET_MOVE_TEXT = 505;

    Handler bluetoothHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch(msg.what){
                default:
                    break;
                case MSG_HANDLER:
                    bluetoothThreadHandler = (Handler) msg.obj;
                    initializeActivity();
                    break;
                case MSG_TOAST:
                    makeToast((String) msg.obj);
                    break;
                case MSG_START_CONNECTION_DIALOG:
                    startConnectingDialog();
                    break;
                case MSG_BEACON_REGISTERED:
                    beaconRegistered();
                    break;
                case MSG_RETURN_SESSION_DATA:
                    Bundle bundle = msg.getData();
                    audioAvg = (double) bundle.get("audioAvg");
                    tempHigh = (double) bundle.get("tempHight");
                    tempLow = (double) bundle.get("tempLow");
                    tempAvg = (double) bundle.get("tempAvg");
                    humAvg = (double) bundle.get("humAvg");
                    humTotal = (double) bundle.get("humTotal");
                    tempTotal = (double) bundle.get("tempTotal");
                    moveAvg = (double) bundle.get("moveAvg");
                    moveTotal = (double) bundle.get("moveTotal");
                    baroAvg = (double) bundle.get("baroAvg");
                    baroTotal = (double) bundle.get("baroTotal");
                    lightAvg = (double) bundle.get("lightAvg");
                    lightTotal = (double) bundle.get("lightTotal");
                    //Uploads data in new asynctask
                    new UploadData(MainActivity.this,MainActivity.this)
                            .execute(results_server + DatabasePool.getBeaconAddr(context));
                    break;
                case MSG_CONNECTED:
                    bleConnected = true;
                    break;
                case MSG_DISCONNECTED:
                    bleConnected = false;
                    break;
                case MSG_CLEAR_DISPLAY_VALUES:
                    clearDisplayValues();
                    break;
                case MSG_SET_AUDIO_TEXT:
                    mAudio.setText((String) msg.obj);
                    break;
                case MSG_SET_TEMP_HUM_TEXT:
                    mTemperature.setText((String) msg.obj);
                    break;
                case MSG_SET_LIGHT_TEXT:
                    mLight.setText((String) msg.obj);
                    break;
                case MSG_SET_PRESSURE_TEXT:
                    mPressure.setText((String) msg.obj);
                    break;
                case MSG_SET_MOVE_TEXT:
                    mMove.setText((String) msg.obj);
                    break;
            }
            return false;
        }
    });

    // This defines what happens when the activity is built
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        context = getApplicationContext();
        DatabasePool.clearExistingDb(context);  //not in Evan's code
       // activity = this;

        setContentView(R.layout.activity_main);
        setProgressBarIndeterminate(true);

        // This creates the toolbar at the top
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Creating the textView on the screen
        mAudio = findViewById(R.id.audio);
        mTemperature = findViewById(R.id.temp);
        mPressure = findViewById(R.id.baro);
        mLight = findViewById(R.id.light);
        mMove = findViewById(R.id.move);
        data = findViewById(R.id.editText);

        // This is the bluetooth Manager that manages if bluetooth is on or not
        final BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = manager.getAdapter();

        // Array for the bluetooth devices
        mDevices = new SparseArray<>();

        // Creating progress bar for loading
        mProgress = new ProgressDialog(this);
        mProgress.setIndeterminate(true);
        mProgress.setCancelable(false);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        //Open location manager
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        //Check permissions when app opens to save time later
        if (!checkLocation())
            return;
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSION_ACCESS_COARSE_LOCATION);
        }
        startStopButton = getWindow().findViewById(R.id.startStopButton);
        disconnectConnectButton = getWindow().findViewById(R.id.disconnectConnectButton);
        registerDeregisterButton = getWindow().findViewById(R.id.registerDeregisterButton);

        beaconRegistered = DatabasePool.hasBeaconAddr(context);

        //Create the thread for handling bluetooth
        bluetoothThread = new BluetoothThread(activity, context, bluetoothHandler);
        bluetoothThread.start();

        SharedPreferences mPrefs = getSharedPreferences("label", 0);  ///none of this is in Evan's code
        previousDateSubmitted = mPrefs.getString("previousDateSubmitted", "1995-03-07");
        Log.i("FROM MEMORY:", " previousDateSubmitted: " + previousDateSubmitted);
    }

    private void initializeActivity(){
        if(beaconRegistered){
            registerDeregisterButton.setText(R.string.title_deregister);
            startConnectingDialog();
            bluetoothThreadHandler.sendMessage(createMessage(BluetoothThread.MSG_SCAN_CONNECT, DatabasePool.getBeaconAddr(context)));
        }
    }

    private Message createMessage(int type, Object obj){
        Message msg = Message.obtain(null, type);
        msg.obj = obj;
        return msg;
    }

    private void makeToast(String msg){
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public static BluetoothAdapter getmBluetoothAdapter() {
        return mBluetoothAdapter;
    }

    public static SparseArray<BluetoothDevice> getmDevices() {
        return mDevices;
    }

    public static boolean isSessionAllowed(){
        return sessionAllowed;
    }

    public static boolean isBleConnected() {
        return bleConnected;
    }

    public static void connectBLE(){
        bleConnected = true;
    }

    public static void disconnectBLE(){
        bleConnected = false;
    }

    public void startSurvey(View v) {
        Intent intObj = new Intent(this, SurveyActivity.class);
        startActivity(intObj);
    }

    //Check if location is enabled, show alert if it isn't
    private boolean checkLocation() {
        if (!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    //Alert that location isn't enabled on phone
    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'.\nPlease Enable Location to " +
                        "use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                    }
                });
        dialog.show();
    }

    //Is location enabled?
    private boolean isLocationEnabled() {
        return locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Make sure that bluetooth is still enabled when we resume application

        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            // Bluetooth is disabled. Exit program to enable
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBtIntent);
            finish();
            return;
        }

        // Also ensuring that LE support is there for side-booted devices
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)){
            Toast.makeText(this, "No LE Support.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        clearDisplayValues();
    }

    @Override
    protected  void onPause() {
        super.onPause();
        // Make sure dialog is hidden
        mProgress.dismiss();
        if(connectingDialog != null) {
            connectingDialog.dismiss();
        }
    }

    @Override
    protected void onDestroy() {
        // Disconnect from any active tag connection
        if(connectingDialog != null) {
            connectingDialog.dismiss();
        }
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    // Data needs to be saved for the the program here!!!


    // Determines how the option menu is created
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Add the 'scan' option to the menu
        getMenuInflater().inflate(R.menu.menu_main, menu);
        // Add any device elements we found
        for (int i = 0; i < mDevices.size(); i++){
            BluetoothDevice device = mDevices.valueAt(i);
            menu.add(0, mDevices.keyAt(i), 0, device.getName() + formatAddrForMenu(device.getAddress()));
        }

        return true;

    }

    private String formatAddrForMenu(String addr){
        return " (" + addr.substring(addr.length() - 5, addr.length()) + ")";
    }

    // Defines what happens when the action bar is selected
    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_quit:
                mDevices.clear();
                finish();
                System.exit(0);
                return true;
            default:
                AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.Theme_AppCompat_Dialog_Alert);
                builder.setTitle("Register beacon");
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.setMessage("Register " + mDevices.get(item.getItemId()).getName() + " (" + mDevices.get(item.getItemId()).getAddress() + ") ?" );
                builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context, "Registered beacon " + mDevices.get(item.getItemId()).getAddress(), Toast.LENGTH_SHORT).show();
                        Message msg = Message.obtain(null, BluetoothThread.MSG_CONNECT_TO_BEACON);
                        msg.obj = mDevices.get(item.getItemId()).getAddress();
                        bluetoothThreadHandler.sendMessage(msg);
                    }
                });
                builder.setNegativeButton("No", null);
                builder.show();
                return super.onOptionsItemSelected(item);
        }

    }

    //Creates dialog to let user know that beacon is still connecting
    public void startConnectingDialog(){
        connectingDialog = new Dialog(this, R.style.Theme_AppCompat_Dialog_Alert);
        connectingDialog.setContentView(R.layout.dialog_upload);
        TextView title = connectingDialog.getWindow().findViewById(R.id.uploadDataTitle);
        title.setText("Connecting to Beacon");
        ProgressBar progress = connectingDialog.getWindow().findViewById(R.id.uploadDataProgress);
        progress.setIndeterminate(true);
        connectingDialog.show();
    }

    //Dismisses connecting dialog
    public static void dismissConnectingDialog(){
        if(connectingDialog != null) {
            connectingDialog.dismiss();
        }
    }

    // Clears the values
    public void clearDisplayValues() {

        mTemperature.setText("---");
        mAudio.setText("");
        mLight.setText("");
        mPressure.setText("");
    }

    public void beaconRegistered(){
        registerDeregisterButton.setText(R.string.title_deregister);
        beaconRegistered = true;
        disconnectConnectButton.setText(R.string.title_disconnect);
    }

    // custom class designed for connecting BLE
    public void bleRegisterDeregister(final View view){
        if(beaconRegistered){
            AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.Theme_AppCompat_Dialog_Alert);
            builder.setTitle("Deregister beacon");
            builder.setIcon(android.R.drawable.ic_dialog_alert);
            builder.setMessage("This will deregister your beacon. Continue?");
            builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    beaconRegistered = false;
                    registerDeregisterButton.setText(R.string.title_scan);
                    Toast.makeText(context, "Deregistered beacon " + DatabasePool.getBeaconAddr(context), Toast.LENGTH_SHORT).show();
                    DatabasePool.clearBeaconAddr(context);
                    if(bleConnected){
                        bleDisconnect(view);
                    }
                }
            });
            builder.setNegativeButton("No", null);
            builder.show();
        }else {
            Toast.makeText(this, "Starting BLE Search", Toast.LENGTH_SHORT).show();
            mDevices.clear();
            bluetoothThreadHandler.sendMessage(Message.obtain(null, BluetoothThread.MSG_START_SCAN));
        }
    }

    //method for starting or stopping activity on button press
    public void startStopSession(View view){
            startSession(view);
    }

    public void resetSessionInformation(){
        sessionAllowed = false;
        timeStart = 0;
        timeEnd = 0;
        tempLow = 100;
        tempHigh = -100;
        cycle = 0;
        tempTotal = 0;
        humAvg = 0;
        humTotal = 0;
        Log.d("TAG", "Session Information Cleared");
        startStopButton.setText(R.string.title_start);
    }

    String getDatetime(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.CANADA);
        dateFormat.setTimeZone(TimeZone.getDefault());
        return dateFormat.format(new Date());
    }

    // custom class designed for lecture mode
    public void startSession(View view){

        // Allow for new Session to start Running
        if (bleConnected) {
            final AlertDialog.Builder builder1 = new AlertDialog.Builder(this); //Changes from Evan's code (outdated?)
            builder1.setTitle("Are you sure you are ready to start?  ");
            builder1.setMessage("You will not be able to go back until the survey is complete.");
            builder1.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    sessionNumber = 1;


                    day_Text = getDatetime();

                    sessionAllowed = true;
                    if(DatabasePool.getDb() != null){
                        DatabasePool.deleteDb(context);
                    }
                    DatabasePool.startDatabase(context);
                    Toast.makeText(MainActivity.this, "Session Started", Toast.LENGTH_SHORT).show();

                    bluetoothThreadHandler.sendMessage(Message.obtain(null, BluetoothThread.MSG_RESET_SESSION_VALUES));
                    timeEnd = 0;
                    timeStart = System.currentTimeMillis() / 1000;

                    Intent intent = new Intent(context, SurveyActivity.class);
                    intent.putExtra("previousDateSubmitted", previousDateSubmitted);
                    startActivityForResult(intent, SURVEY_REQUEST);
                }
            });
            builder1.setNegativeButton("NO", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder1.show();

        }
        else if (!bleConnected){
            Toast.makeText(this, "No Device Connected...", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == SURVEY_REQUEST){
            Toast.makeText(this, "Ending Session", Toast.LENGTH_SHORT).show();
            timeEnd = System.currentTimeMillis() / 1000;
            sessionAllowed = false;
            questions = data.getIntegerArrayListExtra("answers");
            previousDateSubmitted=data.getStringExtra("previousDateSubmitted");
            //The response to this message starts the upload of the data
            bluetoothThreadHandler.sendMessage(Message.obtain(null, BluetoothThread.MSG_STOP_SESSION));
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    //Method for swapping disconnect button
    public void bleConnectDisconnect(View view){
        if(bleConnected){
            bleDisconnect(view);
        }else{
            if(DatabasePool.hasBeaconAddr(context)){
                beaconRegistered = true;
                mDevices.clear();
                startConnectingDialog();
                Message msg = Message.obtain(null, BluetoothThread.MSG_SCAN_CONNECT);
                msg.obj = DatabasePool.getBeaconAddr(context);
                bluetoothThreadHandler.sendMessage(msg);
            }else{
                Toast.makeText(this, "No beacon registered", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // custom class designed for study mode
    public void bleDisconnect(View view){
        bleConnected = false;
        sessionAllowed = false;
        Toast.makeText(this, "Disconnecting from Device(s)", Toast.LENGTH_SHORT).show();

        // Disconnect from any active tag connection
        mDevices.clear();
        invalidateOptionsMenu();
        bluetoothThreadHandler.sendMessage(Message.obtain(null, BluetoothThread.MSG_DISCONNECT_BEACON));
        disconnectConnectButton.setText(R.string.title_connect);
    }

    // custom class designed for Session Data
    public void sessionData(View view){
        try {
            Log.i("input:", "attempting open file");
            InputStream inputStream = openFileInput(testFile);

            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString;
                StringBuilder stringBuilder = new StringBuilder();

                try {
                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                        stringBuilder.append("\n");
                    }

                    inputStream.close();
                    rawString = stringBuilder.toString();

                } catch (IOException e) {
                    Log.i("input:", "crashing inner");
                    e.printStackTrace();

                }
            }
        }
        catch (FileNotFoundException e) {
            Log.i("input:", "crashing outer");
            e.printStackTrace();
        }
        data.setText(rawString);
    }

    //Getters for session data
    public static long getTimeStart() {
        return timeStart;
    }

    public static long getTimeEnd() {
        return timeEnd;
    }

    public static double getAudioAvg() {
        return audioAvg;
    }

    public static double getTempHigh() {
        return tempHigh;
    }

    public static double getTempLow() {
        return tempLow;
    }

    public static double getTempAvg() {
        return tempAvg;
    }

    public static double getHumAvg() {
        return humAvg;
    }

    public static String getDay_Text() {
        return day_Text;
    }

    public static int getSessionNumber(){
        return sessionNumber;
    }

    public static void changeValues(final int type, final Context context, final MainActivity activity){
        final AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        final EditText input1 = new EditText(context);
        input1.setInputType(InputType.TYPE_CLASS_TEXT);
        builder1.setView(input1);

        switch(type){
            case SERVER:
                builder1.setTitle("New Server Domain");
                input1.setText(results_server);
                break;
            default:
                builder1.setTitle("Unknown dialog type");
                break;
        }


        builder1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch(type){
                    case SERVER:
                        results_server = input1.getText().toString();
                        Toast.makeText(context, "Server Changed", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        Toast.makeText(context, "Dialog dismissed", Toast.LENGTH_SHORT).show();
                        break;
                }

                //retries asynctask
                new UploadData(context, activity).execute(results_server + DatabasePool.getBeaconAddr(context));
            }

        });

        builder1.show();
    }

    public static JSONArray JSONSurveyArray() {
        JSONArray ja = new JSONArray();
        for(int i = 0; i < questions.size(); i++){
            ja.put(questions.get(i));
        }
        return ja;
    }
}
