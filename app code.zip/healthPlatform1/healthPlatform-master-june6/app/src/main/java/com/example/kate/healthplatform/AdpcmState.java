package com.example.kate.healthplatform;

public class AdpcmState {

    private short valprev;
    private byte index;


    public short getValprev() {
        return valprev;
    }
    public void setValprev(short valprev) {
        this.valprev = valprev;
    }
    public byte getIndex() {
        return index;
    }
    public void setIndex(byte index) {
        this.index = index;
    }


}