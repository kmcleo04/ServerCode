package com.example.kate.healthplatform;

import android.content.Context;
import android.content.SharedPreferences;

public final class DatabasePool {
    private static Database experimentDb;

    public static void startDatabase(Context context){
        experimentDb = new Database(context);
    }

    public static void setBeaconAddr(String addr, Context context){
        SharedPreferences pref = context.getSharedPreferences("BeaconPref", 0);
        SharedPreferences.Editor edit = pref.edit();
        edit.putString("Addr", addr);
        edit.apply();
    }

    public static String getBeaconAddr(Context context){
        SharedPreferences pref = context.getSharedPreferences("BeaconPref", 0);
        return pref.getString("Addr", null);
    }

    public static void clearBeaconAddr(Context context){
        SharedPreferences pref = context.getSharedPreferences("BeaconPref", 0);
        SharedPreferences.Editor edit = pref.edit();
        edit.remove("Addr");
        edit.apply();
    }

    public static boolean hasBeaconAddr(Context context){
        SharedPreferences pref = context.getSharedPreferences("BeaconPref", 0);
        return pref.contains("Addr");
    }

    public static Database getDb(){
        return experimentDb;
    }

    public static void finishDb(Context context){
        context.deleteDatabase(experimentDb.getDatabaseName());
        startDatabase(context);
    }

    public static void deleteDb(Context context){
        context.deleteDatabase(experimentDb.getDatabaseName());
    }

    public static void clearExistingDb(Context context){
        startDatabase(context);
        deleteDb(context);
    }
}
