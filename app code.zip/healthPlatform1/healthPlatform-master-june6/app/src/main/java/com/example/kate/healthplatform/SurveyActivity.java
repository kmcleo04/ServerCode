package com.example.kate.healthplatform;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

class Question {
    private String mQuestion;
    private int mType;
    private int mResponse;

    public Question (String question, int type){
        this.mQuestion = question;
        this.mType = type;
        this.mResponse = -1;
    }



    public void setResponse(int response){
        mResponse = response;
    }

    public int getResponse() {
        return mResponse;
    }

    public String getQuestion() {
        return mQuestion;
    }

    public int getType() {
        return mType;
    }


}

public class SurveyActivity extends AppCompatActivity {

    String currentDate="0";
    String previousDateSubmitted="1995-03-07";
    int flag=0;
    CardView mCardView;
    View view;


    private RecyclerView questRecyclerView;

    private RecyclerView.LayoutManager questLayoutManager;

    ArrayList<Question> questions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        currentDate = getDatetime();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);

        Intent intent = getIntent();
        //this flag tells you if something has been submitted today
        previousDateSubmitted=intent.getStringExtra("previousDateSubmitted");


        Log.i("ON CREATE SURVEY: ", "previous date submitted: "+previousDateSubmitted + "  Current Date: " + currentDate);
        if(previousDateSubmitted.equals(currentDate)){
            //do not show sleep questions
            flag=1;
            Log.i("DECISION: ", "do not show sleep questions: ");
        }else{
            //show sleep questions
            flag=0;
            Log.i("DECISION: ", "show sleep questions: ");
        }


        SharedPreferences mPrefs= getSharedPreferences("label", 0);
        SharedPreferences.Editor mEditor = mPrefs.edit();
        mEditor.putString("previousDateSubmitted", previousDateSubmitted).commit();


        questRecyclerView = findViewById(R.id.recyclerView);
        questRecyclerView.setHasFixedSize(true);
        questions = makeQuestion();
        questLayoutManager = new LinearLayoutManager(this);
        questLayoutManager = new GridLayoutManager(this, 1);

        questRecyclerView.setLayoutManager(questLayoutManager);
        QuestionAdapter adapter = new QuestionAdapter(questions);
        questRecyclerView.setAdapter(adapter);


                //.setVisibility(View.VISIBLE);
    }

    private String getDatetime(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.CANADA);
        dateFormat.setTimeZone(TimeZone.getDefault());
        return dateFormat.format(new Date());
    }

    public void submitSurvey(View view){
        try {
            //update the latest submission date
            previousDateSubmitted=currentDate;

            //send update to memory
            SharedPreferences mPrefs= getSharedPreferences("label", 0);
            SharedPreferences.Editor mEditor = mPrefs.edit();
            mEditor.putString("previousDateSubmitted", previousDateSubmitted).commit();
            Log.i("AFTER SUBMISSION: ", "previous date submitted: "+previousDateSubmitted + "  Current Date: " + currentDate);

            ArrayList<Integer> answers = getValueQuestions();
            Intent intent = new Intent();
            intent.putExtra("flag", flag);
            intent.putExtra("previousDateSubmitted", previousDateSubmitted);
            intent.putExtra("answers", answers);
            setResult(RESULT_OK, intent);
            finish();
        } catch(Exception e){
            Toast.makeText(this, "You must respond to all questions", Toast.LENGTH_SHORT).show();
        }
    }
//
//    public void goBack (View view){
//        Intent intObj = new Intent(this, MainActivity.class);
//        startActivity(intObj);
//
//        finish();
//        onBackPressed();
//    }

    private ArrayList<Integer> getValueQuestions() throws Exception{
        ArrayList<Integer> list = new ArrayList<>(3);

        if (flag == 1) {
            for (int i = 0; i < 12; i++) {
                list.add(-1);
            }
            for (int i = 12; i < questions.size(); i++) {
                if (questions.get(i).getResponse() < 0) {
                    throw new Exception();
                }
                list.add(questions.get(i).getResponse());
            }
        }
        else {
            for (int i = 0; i < questions.size(); i++) {
                if (questions.get(i).getResponse() < 0) {
                    throw new Exception();
                }
                list.add(questions.get(i).getResponse());
            }
        }
            return list;

    }



    public class QuestionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        ArrayList<Question> mQuestions;

        class yesnoQuestion extends RecyclerView.ViewHolder{
            TextView question;
            Spinner spinner;

            public yesnoQuestion(View itemView) {
                super(itemView);
                question = itemView.findViewById(R.id.textViewQuestion);
                spinner = itemView.findViewById(R.id.data);
            }
        }

        class timeQuestion extends RecyclerView.ViewHolder{
            TextView question;
            Spinner spinner;
            public timeQuestion(View itemView){
                super(itemView);
                question = itemView.findViewById(R.id.textViewQuestion);
                spinner = itemView.findViewById(R.id.timespinner);
                if (flag==1)
                {
                    question.setVisibility(View.GONE);
                    spinner.setVisibility(View.GONE);
                }



            }
        }
        class radioQuestionRate extends RecyclerView.ViewHolder{

            TextView question;
            RadioGroup rGroup;

            public radioQuestionRate(View itemView) {
                super(itemView);
                question = itemView.findViewById(R.id.textViewQuestion);
                rGroup = itemView.findViewById(R.id.radioQuestion5);
                if (flag==1)
                {
                    question.setVisibility(View.GONE);
                    rGroup.setVisibility(View.GONE);
                }

            }


        }

        class radioQuestionNum extends RecyclerView.ViewHolder{

            TextView question;
            RadioGroup rGroup;

            public radioQuestionNum(View itemView) {
                super(itemView);
                question = itemView.findViewById(R.id.textViewQuestion);
                rGroup = itemView.findViewById(R.id.radioQuestion6);

            }


        }

        class edittextQuestion extends RecyclerView.ViewHolder{

            TextView question;
            EditText response;

            public edittextQuestion(View itemView) {
                super(itemView);
                question = itemView.findViewById(R.id.textViewQuestion);
                response = itemView.findViewById(R.id.questionEditText);
                if (flag==1)
                {
                    question.setVisibility(View.GONE);
                    response.setVisibility(View.GONE);

                }



            }
        }

        class checkboxQuestion extends RecyclerView.ViewHolder{

            TextView  question;
            CheckBox response;
            CheckBox noanswer;

            public checkboxQuestion(View itemView) {
                super(itemView);
                question = itemView.findViewById(R.id.textViewQuestion);
                response = itemView.findViewById(R.id.yesCtv);
                noanswer = itemView.findViewById(R.id.noCtv);
                if (flag==1)
                {
                    question.setVisibility(View.GONE);
                    response.setVisibility(View.GONE);
                    noanswer.setVisibility(View.GONE);
                }

            }
        }

        @Override
        public int getItemViewType(int position) {
            return mQuestions.get(position).getType();
        }

        public QuestionAdapter(ArrayList<Question> questions) {
            mQuestions = questions;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            RecyclerView.ViewHolder viewHolder;
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());

            switch (viewType){
                case TEXTEDIT:
                    View v1 = inflater.inflate(R.layout.quest_view_item_textedit, parent, false);
                    viewHolder = new edittextQuestion(v1);
                    if (flag==1)
                    {
                        v1.setVisibility(View.GONE);
                    }
                    break;
                case RADIOGROUP:
                    View v2 = inflater.inflate(R.layout.quest_view_item_radio, parent, false);
                    viewHolder = new radioQuestionRate(v2);
                     if (flag==1)
                    {
                        v2.setVisibility(View.GONE);
                    }
                    break;
                case CHECKBOX:
                    View v3 = inflater.inflate(R.layout.quest_view_item_check, parent, false);
                    viewHolder = new checkboxQuestion(v3);
                     if (flag==1)
                    {
                        v3.setVisibility(View.GONE);
                    }
                    break;
                case YESNOSPINNER:
                    View v4 = inflater.inflate(R.layout.quest_view_item, parent, false);
                    viewHolder = new yesnoQuestion(v4);
                     if (flag==1)
                    {
                       // v4.setLayoutParams(new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, 100));
                    }
                    break;
                case TIMESPINNER:
                    View v5 = inflater.inflate(R.layout.quest_view_item_time_sp, parent, false);
                    viewHolder = new timeQuestion(v5);
                    if (flag==1)
                    {
                        v5.setVisibility(View.GONE);
                    }
                    break;
                    default:
                    View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.quest_view_item, parent, false);
                    viewHolder = new yesnoQuestion(v);
                    break;
                case RADIOGROUP2:
                    View v6 = inflater.inflate(R.layout.quest_view_item_radio2, parent, false);
                    viewHolder = new radioQuestionNum(v6);
                    if (flag==1)
                    {
                        //v6.setVisibility(View.GONE);
                    }
                    break;
            }
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            switch(holder.getItemViewType()){
                case TEXTEDIT:
                    edittextQuestion vh1 = (edittextQuestion) holder;
                    configTextEdit(vh1, position);
                    break;
                case RADIOGROUP:
                    radioQuestionRate vh2 = (radioQuestionRate) holder;
                    configRadioGroupRate(vh2, position);
                    break;
                case CHECKBOX:
                    checkboxQuestion vh3 = (checkboxQuestion) holder;
                    configCheckbox(vh3, position);
                    break;
                case YESNOSPINNER:
                    yesnoQuestion vh4 = (yesnoQuestion) holder;
                    configYesno(vh4, position);
                    break;
                case TIMESPINNER:
                    timeQuestion vh5 = (timeQuestion) holder;
                    comfigTimespinner (vh5, position);
                    break;
                case RADIOGROUP2:
                    radioQuestionNum vh6 = (radioQuestionNum) holder;
                    configRadioGroupNum(vh6, position);
                    break;
                    default:
                    break;
            }
        }

        private void configTextEdit(final edittextQuestion vh, final int position){
            vh.question.setText(mQuestions.get(position).getQuestion());
            vh.response.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    mQuestions.get(position).setResponse(Integer.parseInt(vh.response.getText().toString()));
                }
            });
        }

        private void configRadioGroupRate(final radioQuestionRate vh, final int position){
            vh.question.setText(mQuestions.get(position).getQuestion());
            vh.rGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    mQuestions.get(position).setResponse(vh.rGroup.indexOfChild(vh.rGroup.findViewById(checkedId)) + 1);
                }
            });
            mQuestions.get(position).setResponse(3);
        }

        private void configRadioGroupNum(final radioQuestionNum vh, final int position){
            vh.question.setText(mQuestions.get(position).getQuestion());
            vh.rGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    mQuestions.get(position).setResponse(vh.rGroup.indexOfChild(vh.rGroup.findViewById(checkedId)) + 1);
                }
            });
            mQuestions.get(position).setResponse(3);
        }
//
        private void configCheckbox(final checkboxQuestion vh, final int position){
            vh.question.setText(mQuestions.get(position).getQuestion());
            vh.response.callOnClick();
            switch(mQuestions.get(position).getResponse()){
                case 1:
                    vh.response.setChecked(true);
                    break;
                case -1:
                    mQuestions.get(position).setResponse(0);
                default:
                    vh.response.setChecked(false);
                    break;
            }
            vh.question.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (vh.response.isChecked()) {
                        vh.response.setChecked(false);
                        mQuestions.get(position).setResponse(0);
                    } else {
                        vh.response.setChecked(true);
                        mQuestions.get(position).setResponse(1);
                    }
                }
            });
        }

        private void comfigTimespinner (final timeQuestion vh, final int position) {
            vh.question.setText(mQuestions.get(position).getQuestion());
            final List<String> spinnerList = Arrays.asList(getResources().getStringArray(R.array.time));
            final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                    R.layout.first_spinner, spinnerList) {
                @Override
                public boolean isEnabled(int position) {
                    if (position == 0)
                        return false;
                    else
                        return true;
                }

                @Override
                public View getDropDownView(int position, View convertView, ViewGroup parent) {
                    View view = super.getDropDownView(position, convertView, parent);
                    TextView tv = (TextView) view;
                    if (position == 0)
                        tv.setTextColor(Color.GRAY);
                    else
                        tv.setTextColor(Color.BLACK);
                    return view;
                }
            };
            spinnerArrayAdapter.setDropDownViewResource(R.layout.first_spinner);
            vh.spinner.setAdapter(spinnerArrayAdapter);
            vh.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    if(pos > 0){
                        TextView tv = view.findViewById(R.id.spinner_first);
                        tv.setTextColor(Color.BLACK);
                        mQuestions.get(vh.getAdapterPosition()).setResponse(pos - 1);
                    }else{
                        parent.setSelection(mQuestions.get(position).getResponse() + 1);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    if(flag== 1) //-----------------------------------------------------------------------------------------------------------------------------------------
                    {
                       // vh.

                    }
                }
            });
        }
        private void configYesno(final yesnoQuestion vh, final int position){
            vh.question.setText(mQuestions.get(position).getQuestion());
            final List<String> spinnerList = Arrays.asList(getResources().getStringArray(R.array.data));
            final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                    R.layout.spinner_item, spinnerList){
                @Override
                public boolean isEnabled(int position){
                    if(position == 0)
                        return false;
                    else
                        return true;
                }
                @Override
                public View getDropDownView(int position, View convertView, ViewGroup parent) {
                    View view = super.getDropDownView(position, convertView, parent);
                    TextView tv = (TextView) view;
                    if(position == 0)
                        tv.setTextColor(Color.GRAY);
                    else
                        tv.setTextColor(Color.BLACK);
                    return view;
                }
            };

            spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item);
            vh.spinner.setAdapter(spinnerArrayAdapter);
            vh.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    if(pos > 0){
                        TextView tv = view.findViewById(R.id.spinner_text);
                        tv.setTextColor(Color.BLACK);
                        mQuestions.get(vh.getAdapterPosition()).setResponse(pos - 1);
                    }else{
                        parent.setSelection(mQuestions.get(position).getResponse() + 1);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }

        @Override
        public int getItemCount() {
            return mQuestions.size();
        }
    }

    private static final int TEXTEDIT = 0;
    private static final int CHECKBOX = 1;
    private static final int RADIOGROUP = 2;
    private static final int YESNOSPINNER = 3;
    private static final int EMPTY = 4;
    private static final int TIMESPINNER = 5;
    private static final int RADIOGROUP2 = 6;

    private ArrayList<Question> makeQuestion(){
        ArrayList<Question> questions = new ArrayList<Question>();
        questions.add(new Question("When did you go to bed last night?", TIMESPINNER));
        questions.add(new Question("How many hours did you spend in bed last night?", TEXTEDIT));
        questions.add(new Question("How many hours of sleep did you get last night?", TEXTEDIT));
        questions.add(new Question("Last night, did you get to sleep within 30 minutes?", CHECKBOX));
        questions.add(new Question("Last night, did you wake up in the middle of the night?", CHECKBOX));
        questions.add(new Question("Last night, did you get up to use the bathroom?", CHECKBOX));
        questions.add(new Question("Last night, did you have trouble breathing properly?", CHECKBOX));
        questions.add(new Question("Last night, did you cough or snore loudly?", CHECKBOX));
        questions.add(new Question("Last night, did you feel too cold?", CHECKBOX));
        questions.add(new Question("Last night, did you feel too hot?", CHECKBOX));
        questions.add(new Question("Last night, did you have bad dreams?", CHECKBOX));
        questions.add(new Question("Last night, did you have pain?", CHECKBOX));
        questions.add(new Question("How would you rate last night's sleep overall?", RADIOGROUP));


        questions.add(new Question("Last night, did you take any type of medication to help you sleep?", YESNOSPINNER));
        //
        questions.add(new Question("Did you have trouble staying awake in the past 24 hours?", YESNOSPINNER));
        questions.add(new Question("Did you have trouble keeping enthusiasm to get things done in the past 24 hours?", YESNOSPINNER));
        questions.add(new Question("Do you feel tired out for no good reason?", YESNOSPINNER));
        questions.add(new Question("Do you feel nervous?", YESNOSPINNER));
        questions.add(new Question("Do you feel so nervous that nothing could calm you down?", YESNOSPINNER));
        questions.add(new Question("Do you feel hopeless?", YESNOSPINNER));
        questions.add(new Question("Do you feel restless or fidgety?", YESNOSPINNER));
        questions.add(new Question("Do you feel so restless you can not sit still?", YESNOSPINNER));
        questions.add(new Question("Do you feel depressed?", YESNOSPINNER));
        questions.add(new Question("Do you feel that everything is an effort?", YESNOSPINNER));
        questions.add(new Question("Do you feel so sad that nothing can cheer you up?", YESNOSPINNER));
        questions.add(new Question("Do you feel worthless?", YESNOSPINNER));
        questions.add(new Question("Are you upset because of something that happened unexpectedly?", YESNOSPINNER));
        questions.add(new Question("Do you feel that you are unable to control the important things in your life?", YESNOSPINNER));
        questions.add(new Question("Do you feel stressed?", YESNOSPINNER));
        questions.add(new Question("Do you feel confident about your ability to handle your personal problems?", YESNOSPINNER));
        questions.add(new Question("Do you feel that things are going your way?", YESNOSPINNER));
        questions.add(new Question("Do you feel that you can not cope with all the things that you have to do?", YESNOSPINNER));
        questions.add(new Question("Do you feel you are able to control irritations in your life?", YESNOSPINNER));
        questions.add(new Question("Do you feel that you are on top of things?", YESNOSPINNER));
        questions.add(new Question("Do you feel angered because of things that are outside of your control?", YESNOSPINNER));
        questions.add(new Question("Do you feel difficulties are piling up so high that you could not overcome them?", YESNOSPINNER));

        questions.add(new Question("How many people are around you right now? (ie. in the same room)", RADIOGROUP2));

        return questions;
    }
}
