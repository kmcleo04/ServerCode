package com.example.kate.healthplatform;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.LinkedList;
import java.util.Queue;

public class BluetoothThread extends Thread implements BluetoothAdapter.LeScanCallback{

    private MainActivity mainActivity;
    private Context context;

    private static final int MY_PERMISSION_ACCESS_COARSE_LOCATION = 11;

    // Defining UUID
    //Audio
    private static final UUID AUDIO_SERVICE = UUID.fromString("F000B000-0451-4000-B000-000000000000");
    private static final UUID AUDIO_DATA_CHAR = UUID.fromString("F000B002-0451-4000-B000-000000000000");
    private static final UUID AUDIO_CONFIG_CHAR = UUID.fromString("F000B001-0451-4000-B000-000000000000");

    //Humidity
    private static final UUID TEMPERATURE_SERVICE = UUID.fromString("F000AA20-0451-4000-B000-000000000000");
    private static final UUID TEMPERATURE_DATA_CHAR = UUID.fromString("F000AA21-0451-4000-B000-000000000000");
    private static final UUID TEMPERATURE_CONFIG_CHAR = UUID.fromString("F000AA22-0451-4000-B000-000000000000");

    private static final UUID IR_SERVICE = UUID.fromString("F000AA00-0451-4000-B000-000000000000");
    private static final UUID IR_DATA_CHAR = UUID.fromString("F000AA01-0451-4000-B000-000000000000");
    private static final UUID IR_CONFIG_CHAR = UUID.fromString("F000AA02-0451-4000-B000-000000000000");

    private static final UUID CONFIG_DESCRIPTOR = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private static final UUID BARO_SERVICE = UUID.fromString("F000AA40-0451-4000-B000-000000000000");
    private static final UUID BARO_DATA_CHAR = UUID.fromString("F000AA41-0451-4000-B000-000000000000");
    private static final UUID BARO_CONFIG_CHAR = UUID.fromString("F000AA42-0451-4000-B000-000000000000");
    private static final UUID BARO_CAL_CHAR = UUID.fromString("F000AA43-0451-4000-B000-000000000000");

    private static final UUID LIGHT_SERVICE = UUID.fromString("F000AA70-0451-4000-B000-000000000000");
    private static final UUID LIGHT_DATA_CHAR = UUID.fromString("F000AA71-0451-4000-B000-000000000000");
    private static final UUID LIGHT_CONFIG_CHAR = UUID.fromString("F000AA72-0451-4000-B000-000000000000");

    //DATA give 18 bits, different directions
    //private static final UUID MOVE_SERVICE = UUID.fromString("F000AA80-0451-4000-B000-000000000000");
    //private static final UUID MOVE_DATA_CHAR = UUID.fromString("F000AA81-0451-4000-B000-000000000000");
   // private static final UUID MOVE_CONFIG_CHAR = UUID.fromString("F000AA82-0451-4000-B000-000000000000");

    //Define survey request
    private static final int SURVEY_REQUEST = 1;

    // Custom variables for bluetooth connection
    private BluetoothGatt mConnectedGatt;
    private Handler mainHandler;
    private Handler returnHandler;

    // This is the temperature variables needed

    private static int cycle = 0;
    private static double audioAvg = 0;
    private static double tempAvg = 0;
    private static double tempHigh = -100;
    private static double tempLow = 100;
    private static double lightHigh = -100;
    private static double lightLow = 100;
    private static double baroHigh = -100;
    private static double baroLow = 100;
    private static double moveHigh = -100;
    private static double moveLow = 100;
    private static double tempTotal = 0;
    private static double humHigh = -100;
    private static double humLow = 100;
    private static double humAvg = 0;
    private static double humTotal = 0;
    private static double humCurrent = 0;
    private static double baroAvg = 0;
    private static double baroTotal = 0;
    private static double baroCurrent = 0;
    private static double lightAvg = 0;
    private static double lightTotal = 0;
    private static double lightCurrent = 0;
    private static double moveAvg = 0;
    private static double moveTotal = 0;
    private static double moveCurrent = 0;

    // Variables to find sensor tag
    private static final String TAG = "BluetoothGattActivity";
    private static final String DEVICE_NAME = "CC2650 SensorTag";

    // Variables for session running time
    private static boolean click = false;

    //Messages
    static final int MSG_START_SCAN = 301;
    static final int MSG_STOP_SCAN = 302;
    static final int MSG_CONNECT_TO_BEACON = 303;
    static final int MSG_SCAN_CONNECT = 304;
    static final int MSG_DISCONNECT_BEACON = 305;
    static final int MSG_RESET_SESSION_VALUES = 306;
    static final int MSG_STOP_SESSION = 307;

    // Audio sampling
    private static Queue<Double> audioQueue = new LinkedList<>();
    private static int audioIndex = 0;


    BluetoothThread(MainActivity activity, Context context, Handler handler){
        this.mainActivity = activity;
        this.context = context;
        this.returnHandler = handler;
    }

    @SuppressLint("HandlerLeak")
    @Override
    public void run() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
        Looper.prepare();

        mainHandler = new Handler(){
            public void handleMessage(Message msg){
                switch(msg.what){
                    case MSG_START_SCAN:
                        startScan();
                        break;
                    case MSG_STOP_SCAN:
                        stopScan();
                        break;
                    case MSG_CONNECT_TO_BEACON:
                        connectToBeacon((String)msg.obj);
                        break;
                    case MSG_SCAN_CONNECT:
                        startScan();
                        break;
                    case MSG_DISCONNECT_BEACON:
                        if (mConnectedGatt != null) {
                            mConnectedGatt.disconnect();
                            mConnectedGatt = null;
                        }
                        break;
                    case MSG_RESET_SESSION_VALUES:
                        audioAvg = 0;
                        tempHigh = -100;
                        tempLow = 100;
                        tempAvg = 0;
                        lightHigh=-100;
                        lightLow=100;
                        baroHigh=-100;
                        baroLow=100;
                        moveHigh=-100;
                        moveLow=100;
                        humLow=100;
                        baroAvg=0;
                        humCurrent=0;
                        lightAvg=0;
                        lightTotal=0;
                        humAvg = 0;
                        humTotal = 0;
                        moveAvg=0;
                        moveTotal=0;
                        baroTotal=0;
                        cycle = 0;
                        click = false;
                        tempTotal = 0;
                        break;
                    case MSG_STOP_SESSION:
                        Bundle bundle = new Bundle();
                        bundle.putDouble("audioAvg", audioAvg);
                        bundle.putDouble("tempHight", tempHigh);
                        bundle.putDouble("tempLow", tempLow);
                        bundle.putDouble("tempAvg", tempAvg);
                        bundle.putDouble("humAvg", humAvg);
                        bundle.putDouble("humTotal", humTotal);
                        bundle.putDouble("tempTotal", tempTotal);
                        bundle.putDouble("lightAvg", lightAvg);
                        bundle.putDouble("lightTotal", lightTotal);
                        bundle.putDouble("baroAvg", baroAvg);
                        bundle.putDouble("baroTotal", baroTotal);
                        bundle.putDouble("moveAvg", moveAvg);
                        bundle.putDouble("moveTotal", moveTotal);
                        Message innerMsg = Message.obtain(null, MainActivity.MSG_RETURN_SESSION_DATA);
                        innerMsg.setData(bundle);
                        returnHandler.sendMessage(innerMsg);
                    default:
                        break;
                }
            }
        };
        returnHandler.sendMessage(createMessage(MainActivity.MSG_HANDLER, mainHandler));

        Looper.loop();
    }

    // The almighty handler exists here to deal with multi-threads
    private static final int MSG_AUDIO = 101;
    private static final int MSG_TEMPERATURE = 102;
    private static final int MSG_LIGHT = 103;
    private static final int MSG_BARO = 104;
    private static final int MSG_MOVE = 105;
    private static final int MSG_PROGRESS = 201;
    private static final int MSG_DISMISS = 202;
    private static final int MSG_CLEAR = 301;


    // This is the bluetooth adapter le scan method
    //@Override
    public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
        Log.i(TAG, "New LE Device: " + device.getName() + " @ " + rssi);

        // If we only want sensor tags, validate the name
        if (DEVICE_NAME.equals(device.getName())){
            MainActivity.getmDevices().put(device.hashCode(), device);
            Log.i(TAG, "Calling invalidate options menu for: " + device.getName() + " @ " + rssi);
            //Update the overflow menu
            mainActivity.invalidateOptionsMenu();
        }
    }

    private void connectToBeacon(String addr){
        if(!MainActivity.isBleConnected()) {
            // Obtain the discovered device to connect with
            BluetoothDevice device = null;
            for(int i = 0; i < MainActivity.getmDevices().size(); i++){
                if(MainActivity.getmDevices().get(MainActivity.getmDevices().keyAt(i)).getAddress().equals(addr)){
                    device = MainActivity.getmDevices().get(MainActivity.getmDevices().keyAt(i));
                    break;
                }
            }
            if(device == null){
                returnHandler.sendMessage(createMessage(MainActivity.MSG_TOAST, "Could not find registered device " + DatabasePool.getBeaconAddr(context)));
                MainActivity.dismissConnectingDialog();
                return;
            }
            Log.i(TAG, "Connecting to " + device.getName());

            if(!DatabasePool.hasBeaconAddr(context)){
                returnHandler.sendMessage(Message.obtain(null, MainActivity.MSG_START_CONNECTION_DIALOG));
            }
            // Connect to the device with GATT
            mConnectedGatt = device.connectGatt(context, true, mGattCallback);
            // Display progress UI
            mHandler.sendMessage(Message.obtain(null, MSG_PROGRESS, "Connecting to" + device.getName() + "..."));
        }else{
            Toast.makeText(context, "Please disconnect from current device first", Toast.LENGTH_SHORT).show();
        }
    }

    // This is what happens when the scan is started
    private void startScan() {
        MainActivity.getmBluetoothAdapter().startLeScan(this);
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                stopScan();
            }
        }, 2000);
    }

    // This is what happens when the scan is to stop
    private void stopScan() {
        MainActivity.getmBluetoothAdapter().stopLeScan(this);
        if(!DatabasePool.hasBeaconAddr(context)) {
            String beaconString;
            switch (MainActivity.getmDevices().size()) {
                default:
                    beaconString = "Found " + Integer.toString(MainActivity.getmDevices().size()) + "devices.";
                    mainActivity.openOptionsMenu();
                    break;
                case -1:
                    beaconString = "Scanning error occurred";
                    break;
                case 0:
                    beaconString = "No devices found";
                    break;
                case 1:
                    beaconString = "Found 1 device";
                    mainActivity.openOptionsMenu();
                    break;
            }
            returnHandler.sendMessage(createMessage(MainActivity.MSG_TOAST, "Done scanning. " + beaconString));
        }else{
            connectToBeacon(DatabasePool.getBeaconAddr(context));
        }
    }

    private Message createMessage(int type, Object obj){
        Message msg = Message.obtain(null, type);
        msg.obj = obj;
        return msg;
    }

    private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        // state machine if other sensors were to be connected
        private int mState = 0;
        private void reset() {mState = 0;}
        private void advance() { mState++; }

        private void enableNextSensor(BluetoothGatt gatt) {
            Log.d(TAG, "Enabling......");
            BluetoothGattCharacteristic characteristic;
            switch (mState) {
                case 0:
                    Log.d(TAG, "Enabling audio sensor");
                    //characteristic = gatt.getService(AUDIO_SERVICE).getCharacteristic(AUDIO_CONFIG_CHAR);
                    //characteristic.setValue(new byte[]{0x02});
                    characteristic = gatt.getService(TEMPERATURE_SERVICE).getCharacteristic(TEMPERATURE_CONFIG_CHAR);
                    characteristic.setValue(new byte[]{0x01});
                    break;

                case 1:
                    Log.d(TAG, "Enabling temperature/humidity sensor");
                    characteristic = gatt.getService(TEMPERATURE_SERVICE).getCharacteristic(TEMPERATURE_CONFIG_CHAR);
                    characteristic.setValue(new byte[]{0x01});
                    break;

                case 2:
                    Log.d(TAG, "Enabling Light sensor");
                    characteristic = gatt.getService(LIGHT_SERVICE).getCharacteristic(LIGHT_CONFIG_CHAR);
                    characteristic.setValue(new byte[]{0x01});
                    break;

                case 3:
                    Log.d(TAG, "Enabling Pressure sensor");
                    characteristic = gatt.getService(BARO_SERVICE).getCharacteristic(BARO_CONFIG_CHAR);
                    characteristic.setValue(new byte[]{0x01});
                    break;

//                case 4:
//                    Log.d(TAG, "Enabling Movement sensor");
//                    characteristic = gatt.getService(MOVE_SERVICE).getCharacteristic(MOVE_CONFIG_CHAR);
//                    characteristic.setValue(new byte[] {0x7F,0x02});
//                    break;
                default:
                    characteristic = null;
                    mHandler.sendEmptyMessage(MSG_DISMISS);
                    Log.i(TAG, "All sensors Enabled");
                    MainActivity.connectBLE();
                    break;
            }

            if (characteristic != null) {
                gatt.writeCharacteristic(characteristic);
            }
            else{
                Log.i(TAG, "Error");
            }
            Log.d(TAG, "End Enable");
        }

        // read the data characteristic value for each sensor
        private void readNextSensor(BluetoothGatt gatt){
            BluetoothGattCharacteristic characteristic;
            switch (mState) {
                case 0:
                    Log.d(TAG, "Reading Audio Sensor");
                    characteristic = gatt.getService(AUDIO_SERVICE).getCharacteristic(AUDIO_DATA_CHAR);
                    break;

                case 1:
                    Log.d(TAG, "Reading Temperature/humidity Sensor");
                    characteristic = gatt.getService(TEMPERATURE_SERVICE).getCharacteristic(TEMPERATURE_DATA_CHAR);
                    break;

                case 2:
                    Log.d(TAG, "Reading Light");
                    characteristic = gatt.getService(LIGHT_SERVICE).getCharacteristic(LIGHT_DATA_CHAR);
                    break;

                case 3:
                    Log.d(TAG, "Reading Pressure");
                    characteristic = gatt.getService(BARO_SERVICE).getCharacteristic(BARO_DATA_CHAR);
                    break;

//                case 4:
//                    Log.d(TAG, "Reading Movement");
//                    characteristic = gatt.getService(MOVE_SERVICE).getCharacteristic(MOVE_DATA_CHAR);
//                    break;

                default:
                    return;
            }
            gatt.readCharacteristic(characteristic);
        }

        // allow for enables in the configuration descriptor
        private void setNotifyNextSensor(BluetoothGatt gatt){
            BluetoothGattCharacteristic characteristic;
            switch (mState){
                case 0:
                    Log.d(TAG, "Set notify audio");
                    characteristic = gatt.getService(AUDIO_SERVICE).getCharacteristic(AUDIO_DATA_CHAR);
                    break;

                case 1:
                    Log.d(TAG, "Set notify temperature");
                    characteristic = gatt.getService(TEMPERATURE_SERVICE).getCharacteristic(TEMPERATURE_DATA_CHAR);
                    break;

                case 2:
                    Log.d(TAG, "Set notify Light");
                    characteristic = gatt.getService(LIGHT_SERVICE).getCharacteristic(LIGHT_DATA_CHAR);
                    break;

                case 3:
                    Log.d(TAG, "Set notify Pressure");
                    characteristic = gatt.getService(BARO_SERVICE).getCharacteristic(BARO_DATA_CHAR);
                    break;

//                case 4:
//                    Log.d(TAG, "Set notify Movement");
//                    characteristic = gatt.getService(MOVE_SERVICE).getCharacteristic(MOVE_DATA_CHAR);
//                    break;

                default:
                    mHandler.sendEmptyMessage(MSG_DISMISS);
                    Log.i(TAG, "All Sensors notified");
                    return;
            }

            // Enable local notifications
            gatt.setCharacteristicNotification(characteristic, true);
            Log.i(TAG, "notifications enabled");
            // Enable remote notifications
            BluetoothGattDescriptor desc = characteristic.getDescriptor(CONFIG_DESCRIPTOR);
            desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);

            gatt.writeDescriptor(desc);
        }


        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.d(TAG, "Connection State Change: " + status + " -> " + connectionState(newState));
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                // Must discover services once discovered
                gatt.discoverServices();
                mHandler.sendMessage(Message.obtain(null, MSG_PROGRESS, "Discovering Services..."));
            }
            else if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_DISCONNECTED) {
                // we got disconnected
                mHandler.sendEmptyMessage(MSG_CLEAR);
            }
            else if (status != BluetoothGatt.GATT_SUCCESS) {
                // we failed
                gatt.disconnect();
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status){
            Log.d(TAG, "Services Discovered: " + status);
            mHandler.sendMessage(Message.obtain(null, MSG_PROGRESS, "Enabling sensor..."));
            // reset
            reset();
            enableNextSensor(gatt);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status){
            // For each read, pass the data up to the UI thread
            if (AUDIO_DATA_CHAR.equals(characteristic.getUuid())){
                mHandler.sendMessage(Message.obtain(null, MSG_AUDIO, characteristic));
                Log.d(TAG, "On Characteristic Read audio: ");
            }
            if (TEMPERATURE_DATA_CHAR.equals(characteristic.getUuid())){
                mHandler.sendMessage(Message.obtain(null, MSG_TEMPERATURE, characteristic));
                Log.d(TAG, "On Characteristic Read temp: ");
            }
            if (LIGHT_DATA_CHAR.equals(characteristic.getUuid())){
                mHandler.sendMessage(Message.obtain(null, MSG_LIGHT, characteristic));
                Log.d(TAG, "On Characteristic Read light: ");
            }
            if (BARO_DATA_CHAR.equals(characteristic.getUuid())){
                mHandler.sendMessage(Message.obtain(null, MSG_BARO, characteristic));
                Log.d(TAG, "On Characteristic Read baro: ");
            }
//            if (MOVE_DATA_CHAR.equals(characteristic.getUuid())){
//                mHandler.sendMessage(Message.obtain(null, MSG_MOVE, characteristic));
//                Log.d(TAG, "On Characteristic Read move: ");
//            }

            setNotifyNextSensor(gatt);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status){
            // writes enable flag, now we read initial value
            readNextSensor(gatt);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            // after notifications enabled, all updates go here
            if (AUDIO_DATA_CHAR.equals(characteristic.getUuid())){
                mHandler.sendMessage(Message.obtain(null, MSG_AUDIO, characteristic));
                Log.d(TAG, "On Characteristic Changed audio: ");
            }
            if (TEMPERATURE_DATA_CHAR.equals(characteristic.getUuid())){
                mHandler.sendMessage(Message.obtain(null, MSG_TEMPERATURE, characteristic));
                Log.d(TAG, "On Characteristic Changed temp: ");
            }
            if (LIGHT_DATA_CHAR.equals(characteristic.getUuid())){
                mHandler.sendMessage(Message.obtain(null, MSG_LIGHT, characteristic));
                Log.d(TAG, "On Characteristic Changed light: ");
            }
            if (BARO_DATA_CHAR.equals(characteristic.getUuid())){
                mHandler.sendMessage(Message.obtain(null, MSG_BARO, characteristic));
                Log.d(TAG, "On Characteristic Changed baro: ");
            }
//            if (MOVE_DATA_CHAR.equals(characteristic.getUuid())){
//                mHandler.sendMessage(Message.obtain(null, MSG_MOVE, characteristic));
//                Log.d(TAG, "On Characteristic Changed move: ");
//            }

        }


        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status){
            // once notifications are enabled, we move to the next sensor to start the enable
            advance();
            enableNextSensor(gatt);
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status){
            Log.d(TAG, "Remote RSSI: " + rssi);
        }

        private String connectionState(int status) {
            switch (status) {
                case BluetoothProfile.STATE_CONNECTED:
                    return "Connected";
                case BluetoothProfile.STATE_DISCONNECTED:
                    return "Disconnected";
                case BluetoothProfile.STATE_CONNECTING:
                    return "Connecting";
                case BluetoothProfile.STATE_DISCONNECTING:
                    return "Disconnecting";
                default:
                    return String.valueOf(status);
            }
        }

    };

    private Handler mHandler = new Handler(new Handler.Callback() {

        @Override
        public boolean handleMessage(Message msg) {
            BluetoothGattCharacteristic characteristic;
            switch (msg.what) {
                case MSG_AUDIO:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining audio value");
                        return false;
                    }
                    updateAudioValues(characteristic);
                    break;
                case MSG_TEMPERATURE:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining temperature value");
                        return false;
                    }
                    updateTemperatureValues(characteristic);
                    break;
                case MSG_LIGHT:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining light value");
                        return false;
                    }
                    updateLightValues(characteristic);
                    break;
                case MSG_BARO:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining pressure value");
                        return false;
                    }
                    updatePressureValues(characteristic);
                    break;
                case MSG_MOVE:
//                    characteristic = (BluetoothGattCharacteristic) msg.obj;
//                    if (characteristic.getValue() == null) {
//                        Log.w(TAG, "Error obtaining movement value");
//                        return false;
//                    }
//                    updateMoveValues(characteristic);
                    break;
                case MSG_PROGRESS:
                    break;
                case MSG_DISMISS:
                    MainActivity.dismissConnectingDialog();
                    DatabasePool.setBeaconAddr(mConnectedGatt.getDevice().getAddress(), context);
                    returnHandler.sendMessage(Message.obtain(null, MainActivity.MSG_BEACON_REGISTERED));
                    break;
                case MSG_CLEAR:
                    returnHandler.sendMessage(Message.obtain(null, MainActivity.MSG_CLEAR_DISPLAY_VALUES));
                    break;

            }
            return true;
        }
    });

    private void updateAudioValues(BluetoothGattCharacteristic characteristic) {
        double audio = extractAudio(characteristic);
        double tmpAudio;

        audioQueue.add(audio);
        Queue<Double> tmpQueue = new LinkedList<>(audioQueue);

        if(audioQueue.size() > 200){
            audioQueue.remove();
        }

        while(tmpQueue.size() > 0){

            if (tmpQueue.peek() < 200 && tmpQueue.peek() > -200) {
                audioAvg += Math.abs(tmpQueue.remove());
            }
            else{
                tmpQueue.remove();
            }
        }
        audioAvg /= audioQueue.size();

        returnHandler.sendMessage(createMessage(MainActivity.MSG_SET_AUDIO_TEXT,
                String.format(Locale.CANADA, "Current Audio: %.0f dBA", audioAvg,
                        humCurrent,
                        DatabasePool.getBeaconAddr(context)
                )));
    }

    // methods to display temperature data
    private void updateTemperatureValues(BluetoothGattCharacteristic characteristic) {
        double temperature = extractTemperature(characteristic);
        returnHandler.sendMessage(createMessage(MainActivity.MSG_SET_TEMP_HUM_TEXT,
                String.format(Locale.CANADA, "Current Temperature: %.0f " + (char) 0x00B0 + "C\nCurrent Humidity: %.0f%% \nAddress: %s",
                        temperature,
                        humCurrent,
                        DatabasePool.getBeaconAddr(context)
                )));
    }

    private void updateLightValues(BluetoothGattCharacteristic characteristic) {

        double light = extractLight(characteristic);
        returnHandler.sendMessage(createMessage(MainActivity.MSG_SET_LIGHT_TEXT,
                String.format(Locale.CANADA, "Current Light: %.0f lux", light,
                        humCurrent,
                        DatabasePool.getBeaconAddr(context)
                )));
    }

    private void updatePressureValues(BluetoothGattCharacteristic characteristic) {
        double pressure = extractPressure(characteristic);

        returnHandler.sendMessage(createMessage(MainActivity.MSG_SET_PRESSURE_TEXT,
                String.format(Locale.CANADA, "Current Pressure: %.0f kPa", pressure,
                        humCurrent,
                        DatabasePool.getBeaconAddr(context)
                )));
    }

    private void updateMoveValues(BluetoothGattCharacteristic characteristic) {
        double array[]=extractMove(characteristic);

        returnHandler.sendMessage(createMessage(MainActivity.MSG_SET_MOVE_TEXT,
                String.format(Locale.CANADA, "Current Gyroscope: %.2f X, %.2fY, %.2f Z\nCurrent Accelerometer: %.2f X, %.2fY, %.2f Z", array[0], array[1], array[2], array[3], array[4], array[5],
                        humCurrent,
                        DatabasePool.getBeaconAddr(context)
                )));
    }


    // method to calculate audio data
    private static double extractAudio(BluetoothGattCharacteristic characteristic) {
        int i;
        short audio[] = new short[20];
        int audioAvg = 0;
        AdpcmState audioState = new AdpcmState();

        // Increasing Cycle Count
        if (!click) {
            cycle = 0;
            click = true;
            audioAvg = 0;
        }
        cycle++;

        byte rawAudio[] = new byte[20];
        // Getting raw binary audio data
        for (i=0; i<19; i++) {
            rawAudio[i] = (byte) (shortUnsignedAtOffset(characteristic, i) >> 0);
            //rawAudio[i+1] = (byte) (shortUnsignedAtOffset(characteristic, i) >> 0);
        }

        // Determining audio
        audioState.setValprev((byte)audioAvg);
        audioState.setIndex((byte)audioIndex);
        audioIndex++;
        if(audioIndex > 19){
            audioIndex = 0;
        }
        Adpcm.adpcmDecoder (rawAudio, audio, rawAudio.length, audioState);

        for(i=0; i<audio.length; i++){
            audioAvg += audio[i];
        }
        audioAvg = audioAvg / i;

        Log.i(TAG, "Audio: " +  audioAvg);

        if(MainActivity.isSessionAllowed()) {
            DatabasePool.getDb().insertAudioSensorData(audioAvg);
        }

        return audioAvg;
    }

    // method to calculate temperature data
    private static double extractTemperature(BluetoothGattCharacteristic characteristic) {

        // Increasing Cycle Count
        if (!click) {
            cycle = 0;
            click = true;
            tempAvg = 0;
            tempTotal = 0;
            humAvg = 0;
            humTotal = 0;
        }
        cycle++;

        // Getting raw binary temperature data
        int rawTemp = shortSignedAtOffset(characteristic, 0);
        int rawHum = shortUnsignedAtOffset(characteristic, 2);

        // Determining temperature
        double temp;
        double hum;

        //-- calculate relative humidity [%RH]
        hum = ((double)rawHum / 65536)*100;

        temp = ((double) rawTemp / 65536) * 165 - 40;
        //Log.i(TAG, "Humidity: " +  hum);

        tempTotal = tempTotal + Math.round(temp);
        humTotal = humTotal + Math.round(hum);

        // Getting average, low, and High
        tempAvg = tempTotal / cycle;
        humAvg = humTotal / cycle;
        humCurrent = hum;
        if (cycle > 10) {

            if (tempHigh < temp) {
                tempHigh = temp;
            }

            if (tempLow > temp) {
                tempLow = temp;
            }
        }
        if (cycle > 10) {

            if (humHigh < hum) {
                humHigh = hum;
            }

            if (humLow > hum) {
                humLow = hum;
            }
        }
        if(MainActivity.isSessionAllowed()) {
            DatabasePool.getDb().insertSensorData(temp, hum);
        }
        return temp;
    }

    public static double extractLight(BluetoothGattCharacteristic characteristic) {
        // Increasing Cycle Count
        if (click == false) {
            cycle = 0;
            click = true;
            lightAvg = 0;
            lightTotal = 0;
        }
        cycle++;

        int rawLight = shortUnsignedAtOffset(characteristic, 0);

        double light;
        //light = ((double)rawLight / 65536)*100;

        int e, m;

        m = rawLight & 0x0FFF;
        e = (rawLight & 0xF000) >> 12;

        /** e on 4 bits stored in a 16 bit unsigned => it can store 2 << (e - 1) with e < 16 */
        e = (e == 0) ? 1 : 2 << (e - 1);

        light= m * (0.01 * e);

        //Log.i(TAG, "Light: " +  light);


        //FOR HISTORY
        lightTotal = lightTotal + Math.round(light);
        lightTotal = lightTotal + Math.round(light);

        // Getting average, low, and High
        lightAvg = lightTotal / cycle;
        lightAvg = lightTotal / cycle;
        lightCurrent = light;
        if (cycle > 10) {

            if (lightHigh < light) {
                lightHigh = light;
            }

            if (lightLow > light) {
                lightLow = light;
            }
        }

        if(MainActivity.isSessionAllowed()) {
            DatabasePool.getDb().insertLightSensorData(light);
        }

        return light;
    }

    public static double extractPressure(BluetoothGattCharacteristic characteristic) {

        // Increasing Cycle Count
        if (click == false) {
            cycle = 0;
            click = true;
            baroAvg = 0;
            baroTotal = 0;
        }
        cycle++;

        int p_r;	// Pressure raw value from sensor
        double p_a; 	// Pressure actual value in unit Pascal.

        p_r = UnsignedAtOffset(characteristic, 3);

        p_a=p_r/1000;

        //Log.i(TAG, "Pressure: " +  p_a);

        //FOR HISTORY
        baroTotal = baroTotal + Math.round(p_a);
        baroTotal = baroTotal + Math.round(p_a);

        // Getting average, low, and High
        baroAvg = baroTotal / cycle;
        baroAvg = baroTotal / cycle;
        baroCurrent = p_a;
        if (cycle > 10) {

            if (baroHigh < p_a) {
                baroHigh = p_a;
            }

            if (baroLow > p_a) {
                baroLow = p_a;
            }
        }

        if(MainActivity.isSessionAllowed()) {
            DatabasePool.getDb().insertPressureSensorData(p_a);
        }

        return p_a;

    }

    public static double[] extractMove(BluetoothGattCharacteristic characteristic) {
        // Increasing Cycle Count
        if (click == false) {
            cycle = 0;
            click = true;
            baroAvg = 0;
            baroTotal = 0;
        }
        cycle++;

        double array[]={0,0,0,0,0,0};

        array[0]=shortSignedAtOffset(characteristic, 0)/ (65536 / 500);
        array[1]=shortSignedAtOffset(characteristic, 2)/ (65536 / 500);
        array[2]=shortSignedAtOffset(characteristic, 4)/ (65536 / 500);
        array[3]=shortSignedAtOffset(characteristic, 6)/ (32768/16);
        array[4]=shortSignedAtOffset(characteristic, 8)/ (32768/16);
        array[5]=shortSignedAtOffset(characteristic, 10)/ (32768/16);

        //Log.i(TAG, "Sample of move: " +  array[0]);

        double gyro=array[0]+array[1]+array[2];

        //FOR HISTORY
        moveTotal = moveTotal + Math.round(gyro);
        moveTotal = moveTotal + Math.round(gyro);

        // Getting average, low, and High
        moveAvg = moveTotal / cycle;
        moveAvg = moveTotal / cycle;
        moveCurrent = gyro;
        if (cycle > 10) {

            if (moveHigh < gyro) {
                moveHigh = gyro;
            }

            if (moveLow > gyro) {
                moveLow = gyro;
            }
        }

        if(MainActivity.isSessionAllowed()) {
            DatabasePool.getDb().insertMoveSensorData(gyro);
        }

        return array;
    }

    // Turning bytes into usable data
    private static Integer shortSignedAtOffset(BluetoothGattCharacteristic c, int offset) {
        Integer lowerByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, offset);
        Integer upperByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_SINT8, offset + 1); // Note: interpret MSB as signed.
        return (upperByte << 8) + lowerByte;
    }

    // Turning bytes into usable data
    private static Integer shortUnsignedAtOffset(BluetoothGattCharacteristic c, int offset) {
        Integer lowerByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, offset);
        Integer upperByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, offset + 1); // Note: interpret MSB as unsigned.
        return (upperByte << 8) + lowerByte;
    }

    private static Integer UnsignedAtOffset(BluetoothGattCharacteristic c, int offset) {
        Integer lowerByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, offset);
        Integer middleByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, offset + 1); // Note: interpret MSB as unsigned.
        Integer upperByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, offset + 2);

        return (upperByte<<16)  + (middleByte<<8) + lowerByte ;
    }
}
